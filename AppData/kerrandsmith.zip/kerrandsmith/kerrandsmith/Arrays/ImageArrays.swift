//
//  ImageArrays.swift
//  kerrandsmith
//
//  Created by Sean Kelly on 15/05/2023.
//

import Foundation

let recoveryImages: [String] = ["rec1", "rec2", "rec3", "rec4", "rec5", "rec6"]

let recoveryLogos: [String] = ["aa", "greenflag", "rac", "lve", "mansfield", "mondial"]
