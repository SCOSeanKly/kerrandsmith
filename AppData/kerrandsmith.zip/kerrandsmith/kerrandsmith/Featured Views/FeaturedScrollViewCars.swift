//
//  ViewBannerImages.swift
//  kerrandsmith
//
//  Created by Sean Kelly on 16/05/2023.
//

import SwiftUI
import SwiftUIMailView

struct FeaturedScrollViewCars: View {
    @ObservedObject var viewModel = DataViewModel()
    
    let urlString = "https://raw.githubusercontent.com/SCOSeanKly/kerrandsmith/main/JSON/featured/featuredCars.json"
    let baseURLString = "https://raw.githubusercontent.com/SCOSeanKly/kerrandsmith/main/FeaturedImages/Cars/"
    
    var body: some View {
        VStack {
            if !viewModel.images.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    LazyHStack {
                        ForEach(viewModel.images) { image in
                            URLImageView(image: image)
                                .cornerRadius(5)
                                .padding(.horizontal, 5)
                        }
                    }
                }
            } else {
                Text("Loading images...")
            }
        }
        .onAppear {
            viewModel.loadImages(fromURLString: urlString, baseURLString: baseURLString)
        }
    }
}

struct URLImageView: View {
    let image: ImageModel
    @State private var showContactFormView: Bool = false
    @State private var showLargeImage: Bool = false
    @State private var showMailView = false
    @State private var mailData: ComposeMailData
    @State private var showingAlert = false
    let imageWidth = UIScreen.main.bounds.width * 0.65
    let imageHeight = UIScreen.main.bounds.width * 0.45
    
    init(image: ImageModel) {
        self.image = image
        _mailData = State(initialValue: ComposeMailData(subject: "Enquiry Type: [Cars] with Kerr & Smith Cumnock",
                                                        recipients: ["ske@kerrandsmith.co.uk"],
                                                        message: """
                                                        \(image.title)\n\(image.subtitle)
                                                        
                                                        Enquiry:
                                                        """,
                                                        attachments: []))}
    
    var body: some View {
        VStack {
            AsyncImage(url: URL(string: image.imageUrlLowRes)) { phase in
                switch phase {
                case .empty:
                    ProgressView()
                case .success(let loadedImage):
                    ZStack {
                        loadedImage
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                        
                        Button {
                            showLargeImage = true
                        }label: {
                            LargeImageViewButton(systemImage: "camera.fill", imageWidth: imageWidth, imageHeight: imageHeight, tintColour: Color.white)
                        }
                        
                    }
                case .failure:
                    Image(systemName: "exclamationmark.triangle")
                @unknown default:
                    EmptyView()
                }
            }
            .frame(width: imageWidth, height: imageHeight)
            .overlay(
                RoundedRectangle(cornerRadius: 5)
                    .stroke(Color.gray, lineWidth: 0.5)
            )
            .clipShape(RoundedRectangle(cornerRadius: 5))
            .sheet(isPresented: $showLargeImage) {
                RoundedRectangle(cornerRadius: 3)
                    .frame(width: 40, height: 6)
                    .foregroundColor(Color.gray.opacity(0.5))
                    .padding(.top, 8)
                
                ScrollView {
                    VStack (alignment: .center) {
                        LargeViewHeader(showContactFormView: $showContactFormView, titleString: image.title, subtitleString: image.subtitle, priceString: image.price)
                
                            Button {
                                saveImageToPhotoAlbum(image.image1)
                                showingAlert.toggle()
                            } label: {
                                LargeImageView(imageURL: image.image1)
                            }
                        
                        
                        Button {
                            saveImageToPhotoAlbum(image.image2)
                            showingAlert.toggle()
                        } label: {
                            LargeImageView(imageURL: image.image2)
                        }
                        
                        LargeViewInfoView()
                        
                        Button {
                            saveImageToPhotoAlbum(image.image3)
                            showingAlert.toggle()
                        } label: {
                            LargeImageView(imageURL: image.image3)
                        }
                        
                        Button {
                            saveImageToPhotoAlbum(image.image4)
                            showingAlert.toggle()
                        } label: {
                            LargeImageView(imageURL: image.image4)
                        }
                        
                        CopyrightView()
                    }
                }
                .alert("Saved to Photos Album", isPresented: $showingAlert) {
                            Button("OK", role: .cancel) { }
                        }
                .prefersPersistentSystemOverlaysHidden()
            }
            
            featuredInfoText(image: image)
            
        }
    }
    
    func saveImageToPhotoAlbum(_ imageURL: String) {
        guard let url = URL(string: imageURL) else {
            // Handle invalid URL
            return
        }

        let session = URLSession.shared
        let task = session.dataTask(with: url) { (data, response, error) in
            if let error = error {
                // Handle network error
                print("Error: \(error)")
                return
            }

            guard let data = data else {
                // Handle missing data
                return
            }

            DispatchQueue.main.async {
                if let image = UIImage(data: data) {
                    UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
                } else {
                    // Handle failed image creation
                }
            }
        }

        task.resume()
    }
}




struct FeaturedScrollViewCars_Previews: PreviewProvider {
    static var previews: some View {
        FeaturedScrollViewCars()
    }
}
