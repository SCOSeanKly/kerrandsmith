//
//  LargeViewButton.swift
//  kerrandsmith
//
//  Created by Sean Kelly on 19/05/2023.
//

import SwiftUI

struct LargeViewButton: View {
    var body: some View {
        VStack {
            Spacer()
            HStack {
                Spacer()
                Image(systemName: "camera.fill")
                    .font(.title2)
                    .tint(.blue)
               //   .shadow(color: Color.black.opacity(0.2), radius: 2, x: 0, y: 0)
                    
            }
            .padding()
        }
        .padding(.bottom, 20.0)
    }
}

struct LargeViewButton_Previews: PreviewProvider {
    static var previews: some View {
        LargeViewButton()
    }
}
