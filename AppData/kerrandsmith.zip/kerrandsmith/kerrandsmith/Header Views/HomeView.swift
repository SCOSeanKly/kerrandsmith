//
//  HomeView.swift
//  kerrandsmith
//
//  Created by Sean Kelly on 15/05/2023.
//

import SwiftUI

struct HomeView: View {
    
    var body: some View {
      
                ScrollingHeader()
                
                ScrollView {
                    
                }
                
                Spacer()
        
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
