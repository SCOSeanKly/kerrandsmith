//
//  kerrandsmithApp.swift
//  kerrandsmith
//
//  Created by Sean Kelly on 15/05/2023.
//

import SwiftUI

@main
struct kerrandsmithApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
